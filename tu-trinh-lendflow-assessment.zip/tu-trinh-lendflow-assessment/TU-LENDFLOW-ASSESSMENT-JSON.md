# LENDFLOW-ASSESSMENT

json
1. Which products are out of stock, not on sale, and under $20?
```javascript
function getOutOfStocks(products) {
    // filter products list with out of stock, not on sale and price below $20
    return products.filter( item => item.in_stock === false && item.on_sale === false && parseFloat(item.price.replace(/[^0-9.-]+/g,"")) < 20)
}
```

2. What is the most commonly used category?
```JS
// declare categories array
let cats = [];

// add product categories to categories array
products.forEach(d => {
    cats = [...cats, ...item.categories]
})

// declare frequency category object that holds the category name as key and frequency as value
const frequencyCats = {};

// each categories if category key exist then add 1
// else create category entry with value 1
cats.forEach(cat => {
    if(frequencyCats[cat]) {
        frequencyCats[cat]++;
    } else {
        frequencyCats[cat] = 1;
    }
});

// sort frequency categories object from most to LEAST
const sortedCats = Object.fromEntries(Object.entries(frequencyCats).sort((a,b) => b[1] - a[1]))
// grab first entry which will be the most common category
const commonCat = Object.keys(sortedCats)[0]
```

3. What is the average price of sale items?
```javascript
// declaration of sales price array
let salesPriceArr = [];

// create array with sales price
salesPriceArr = products.filter(d => item.on_sale === true).map(d => {
    // convert string to number
    return parseFloat(item.price.replace(/[^0-9.-]+/g,""))
})

// total the sale prices
let totalSalesPrice = salesPriceArr.reduce((accumulator, currentValue) => accumulator + currentValue)

// avg is total divide by number of sales items
let avgSalesPrice = (totalSalesPrice/salesPriceArr.length).toFixed(2)

```

4. How many women’s products are out of stock, broken down by color?
```javascript
// declaration of object with color as key and total for each as value
const OutByColor = {};

// get products that are out of stock and female
products.filter(d => item.in_stock === false && item.gender === "female").map(d => {    
    // use map to create key/value to OutByColor object
    if(OutByColor[item.color]) {
        OutByColor[item.color]++
    }else{
        OutByColor[item.color] = 1;
    }
})
```